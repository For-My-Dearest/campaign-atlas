_Medium humanoid (any race), any non-lawful alignment_

---

**Armor Class** 15 (studded leather)  
**Hit Points** 65 (10d8 + 20)  -- 3
**Speed** 30 ft.

---

| STR     | DEX     | CON     | INT     | WIS     | CHA     |
| ------- | ------- | ------- | ------- | ------- | ------- |
| 15 (+2) | 16 (+3) | 14 (+2) | 14 (+2) | 11 (+0) | 14 (+2) |

---

**Saving Throws** Str +4, Dex +5, Wis +2  
**Skills** Athletics +4, Deception +4  
**Senses** passive Perception 10  
**Languages** any two languages  
**Challenge** 2 (450 XP)  
**Proficiency Bonus** +2

---

### Actions

**Multiattack.** The captain makes three melee attacks: two with its scimitar and one with its dagger. Or the captain makes two ranged attacks with its daggers.

**Scimitar.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 6 (1d6 + 3) slashing damage.

**Dagger.** _Melee or Ranged Weapon Attack:_ +5 to hit, reach 5 ft. or range 20/60 ft., one target. _Hit:_ 5 (1d4 + 3) piercing damage.

### Reactions

**Parry.** The captain adds 2 to its AC against one melee attack that would hit it. To do so, the captain must see the attacker and be wielding a melee weapon.