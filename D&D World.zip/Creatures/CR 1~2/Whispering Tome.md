
_Small construct, unaligned_

---

**Armor Class** 14 (natural)  
**Hit Points** 32 (5d6 + 15)  
**Speed** 0 ft., fly 30 ft. (hover)

---

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|6 (-2)|14 (+2)|16 (+3)|10 (+0)|12 (+1)|10 (+0)|

---

**Damage Immunities** poison, psychic  
**Condition Immunities** poisoned, prone  
**Senses** blindsight 30 ft. (blind beyond this radius), passive Perception 11  
**Languages** understands Common but can't speak  
**Challenge** 1 (200 XP)  
**Proficiency Bonus** +2

---

**False Appearance.** While the tome remains motionless and closed on a shelf or desk, it is indistinguishable from a normal book.

**Flyby.** The tome doesn't provoke opportunity attacks when it flies out of an enemy's reach.

**Evasion.** When the tome is subjected to an effect that allows it to make a Dexterity saving throw for half damage, it takes no damage on a success and half damage on a failure.

### Actions

**Multiattack.** The tome makes two Page Slap attacks.

**Page Slap.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one target. _Hit:_ 5 (1d6 + 2) bludgeoning damage.

**Bookmark Dart (Recharge 5-6).** _Ranged Weapon Attack:_ +4 to hit, range 20/60 ft., one target. _Hit:_ 7 (1d8 + 3) piercing damage.

**Parchment Shuffle (Cantrip).** The tome creates one of the following magical effects within 30 feet:

- A page rustles loudly, granting advantage on Stealth checks for one creature hiding nearby.
- A book slides partially off a shelf within 5 feet.
- An illusory whispering voice echoes a 6-second phrase.

### Bonus Actions

**Slam Shut.** The tome slams itself shut. Each creature within 10 feet must succeed on a DC 11 Constitution saving throw or have disadvantage on Wisdom (Perception) checks that rely on hearing until the start of the tome's next turn.