_Tiny fiend (devil), lawful evil_

---

**Armor Class** 13  
**Hit Points** 10 (3d4 + 3)  
**Speed** 20 ft., fly 40 ft.

---

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|6 (-2)|17 (+3)|13 (+1)|11 (+0)|12 (+1)|14 (+2)|

---

**Skills** Deception +4, Insight +3, Persuasion +4, Stealth +5  
**Damage Resistances** cold; bludgeoning, piercing, slashing from nonmagical attacks not made with silvered weapons  
**Damage Immunities** fire, poison  
**Condition Immunities** poisoned  
**Senses** darkvision 120 ft., passive Perception 11  
**Languages** Infernal, Common  
**Challenge** 1 (200 XP)  
**Proficiency Bonus** +2

---

**Shapechanger.** The imp can use its action to polymorph into a beast form (rat, raven, or spider) or back. Its statistics are the same in each form. Any equipment it wears or carries isn't transformed.

**Devil's Sight.** Magical darkness doesn't block the imp's darkvision.

**Magic Resistance.** The imp has advantage on saving throws against spells and other magical effects.

### Actions

**Sting (Bite in Beast Form).** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 5 (1d4 + 3) piercing damage plus 7 (2d6) poison damage. The target must make a DC 11 Constitution saving throw, taking the poison damage on a failed save, or half as much on a successful one.

**Invisibility.** The imp magically turns invisible until it attacks or until its concentration ends (as if concentrating on a spell). Any equipment the imp wears or carries is invisible with it.