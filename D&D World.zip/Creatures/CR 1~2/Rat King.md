_Small monstrosity, unaligned_

---

_This creature is formed when 3–5 rats fuse together into a chittering, writhing mass with multiple heads and tails._

---

**Armor Class** 14 (natural)  
**Hit Points** 45 (7d6 + 21)  
**Speed** 30 ft., climb 20 ft.

---

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|12 (+1)|15 (+2)|16 (+3)|3 (-4)|10 (+0)|5 (-3)|

---

**Saving Throws** Con +5  
**Damage Resistances** bludgeoning, piercing  
**Condition Immunities** frightened, poisoned  
**Senses** darkvision 60 ft., passive Perception 10  
**Languages** —  
**Challenge** 1 (200 XP) or 2 (450 XP) depending on number of rats (see below)  
**Proficiency Bonus** +2

---

**Rat King Variants:**

|Rats consumed|HP|CR|XP|
|---|---|---|---|
|3|33 (6d6 + 12)|1|200|
|4|39 (7d6 + 17)|1|200|
|5|45 (7d6 + 21)|2|450|

**Keen Smell.** The rat king has advantage on Wisdom (Perception) checks that rely on smell.

**Swarm Absorption.** When the rat king kills a giant rat, it regains 5 hit points and adds that rat's mass to itself. After absorbing 2 additional rats, its HP maximum increases by 5 and its size becomes Medium.

**Multiple Heads.** The rat king has advantage on saving throws against being blinded, deafened, stunned, or knocked unconscious. It also has advantage on Perception checks and on saving throws against being charmed or frightened.

### Actions

**Multiattack.** The rat king makes a number of Bite attacks equal to the number of rats it consumed (3, 4, or 5).

**Bite.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one target. _Hit:_ 5 (1d6 + 2) piercing damage.

**Nauseating Chitter (Recharge 5-6).** Each creature within 15 feet must make a DC 12 Constitution saving throw. On a failure, they take 7 (2d6) psychic damage and are unable to take reactions until the end of their next turn.

### Bonus Actions

**Disgorge Rat.** The rat king spits out one giant rat in an unoccupied space within 5 feet. That rat has 5 hit points and acts on the rat king's initiative. The rat king's maximum HP decreases by 5 permanently (until it absorbs more rats).