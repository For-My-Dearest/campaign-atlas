_Tiny fey, neutral good_

---

**Armor Class** 15  
**Hit Points** 1 (1d4 - 1)  
**Speed** 10 ft., fly 30 ft.

---

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|2 (-4)|20 (+5)|8 (-1)|14 (+2)|15 (+2)|18 (+4)|

---

**Skills** Perception +4, Stealth +7  
**Senses** passive Perception 14  
**Languages** Sylvan  
**Challenge** 1/4 (50 XP)  
**Proficiency Bonus** +2

---

**Magic Resistance.** The pixie has advantage on saving throws against spells and other magical effects.

**Superior Invisibility.** The pixie can magically turn invisible until it attacks, casts a spell, or concentration ends (as if concentrating on a spell). Any equipment the pixie wears or carries is invisible with it.

### Spellcasting

The pixie casts one of the following spells, requiring no material components and using Charisma as the spellcasting ability (spell save DC 12):

**At will:** _Druidcraft_  
**1/day each:** _Confusion, Dancing Lights, Detect Evil and Good, Detect Thoughts, Dispel Magic, Entangle, Fly, Phantasmal Force, Polymorph, Sleep_