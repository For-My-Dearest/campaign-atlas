_Small beast, unaligned_

---

**Armor Class** 12  
**Hit Points** 7 (2d6)  
**Speed** 30 ft., climb 15 ft.

---

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|7 (-2)|15 (+2)|11 (+0)|2 (-4)|10 (+0)|4 (-3)|

---

**Senses** darkvision 60 ft., passive Perception 10  
**Languages** —  
**Challenge** 1/8 (25 XP)  
**Proficiency Bonus** +2

---

**Keen Smell.** The rat has advantage on Wisdom (Perception) checks that rely on smell.

**Pack Tactics.** The rat has advantage on attack rolls against a creature if at least one of the rat's allies is within 5 feet of the creature and the ally isn't incapacitated.

### Actions

**Bite.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one target. _Hit:_ 4 (1d4 + 2) piercing damage.