Father: [[Hakan Blackwood]]
Mother: [[Laila Blackwood]]
Daughter: [[Merry Blackwood]]

