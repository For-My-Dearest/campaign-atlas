
| Beast                 | CR  | Size   | HP  | AC  |
| --------------------- | --- | ------ | --- | --- |
| **Brown Bear**        | 1   | Large  | 34  | 11  |
| **Dire Wolf**         | 1   | Large  | 37  | 14  |
| **Giant Spider**      | 1   | Large  | 26  | 14  |
| **Giant Toad**        | 1   | Large  | 39  | 11  |
| **Lion**              | 1   | Large  | 26  | 12  |
| **Tiger**             | 1   | Large  | 37  | 12  |
| **Giant Eagle**       | 1   | Large  | 26  | 13  |
| **Giant Hyena**       | 1   | Large  | 45  | 12  |
| **Crocodile**         | 1/2 | Large  | 19  | 12  |
| **Black Bear**        | 1/2 | Medium | 19  | 11  |
| **Ape**               | 1/2 | Medium | 19  | 12  |
| **Giant Goat**        | 1/2 | Large  | 19  | 11  |
| **Warhorse**          | 1/2 | Large  | 19  | 10  |
| **Giant Wasp**        | 1/2 | Medium | 13  | 12  |
| **Giant Wolf Spider** | 1/4 | Medium | 11  | 13  |
| **Giant Frog**        | 1/4 | Medium | 18  | 11  |
| **Giant Lizard**      | 1/4 | Large  | 19  | 12  |
| **Wolf**              | 1/4 | Medium | 11  | 13  |
| **Boar**              | 1/4 | Medium | 11  | 11  |
| **Giant Owl**         | 1/4 | Large  | 19  | 12  |
| **Riding Horse**      | 1/4 | Large  | 13  | 10  |
| **Elk**               | 1/4 | Large  | 13  | 10  |
| **Panther**           | 1/4 | Medium | 13  | 12  |
| **Constrictor Snake** | 1/4 | Large  | 13  | 12  |
| **Poisonous Snake**   | 1/8 | Tiny   | 2   | 13  |
| **Giant Rat**         | 1/8 | Small  | 7   | 12  |
| **Mastiff**           | 1/8 | Medium | 5   | 12  |
| **Camel**             | 1/8 | Large  | 15  | 9   |
| **Flying Snake**      | 1/8 | Tiny   | 5   | 14  |
| **Giant Crab**        | 1/8 | Medium | 13  | 15  |
| **Giant Weasel**      | 1/8 | Medium | 9   | 13  |
| **Blood Hawk**        | 1/8 | Small  | 7   | 12  |
| **Baboon** (0)        | 0   | Small  | 3   | 12  |
| **Badger** (0)        | 0   | Tiny   | 3   | 10  |
| **Cat** (0)           | 0   | Tiny   | 2   | 12  |
| **Deer** (0)          | 0   | Medium | 4   | 13  |
| **Eagle** (0)         | 0   | Small  | 3   | 12  |
| **Frog** (0)          | 0   | Tiny   | 1   | 11  |
| **Goat** (0)          | 0   | Medium | 4   | 10  |
| **Hawk** (0)          | 0   | Tiny   | 1   | 13  |
| **Hyena** (0)         | 0   | Medium | 5   | 11  |
| **Jackal** (0)        | 0   | Small  | 3   | 12  |
| **Lizard** (0)        | 0   | Tiny   | 2   | 10  |
| **Octopus** (0)       | 0   | Small  | 3   | 12  |
| **Owl** (0)           | 0   | Tiny   | 1   | 11  |
| **Rat** (0)           | 0   | Tiny   | 1   | 10  |
| **Raven** (0)         | 0   | Tiny   | 1   | 12  |
| **Scorpion** (0)      | 0   | Tiny   | 1   | 11  |
| **Spider** (0)        | 0   | Tiny   | 1   | 12  |
| **Weasel** (0)        | 0   | Tiny   | 1   | 13  |

## CR 1 Beasts (Best Combat Options)
### Brown Bear

_Large beast, unaligned_

**Armor Class** 11  
**Hit Points** 34 (4d10 + 12)  
**Speed** 40 ft., climb 30 ft.

| STR     | DEX     | CON     | INT    | WIS     | CHA    |
| ------- | ------- | ------- | ------ | ------- | ------ |
| 19 (+4) | 10 (+0) | 16 (+3) | 2 (-4) | 13 (+1) | 7 (-2) |

**Skills** Perception +3  
**Senses** passive Perception 13  
**Challenge** 1 (200 XP)

**Keen Smell.** The bear has advantage on Wisdom (Perception) checks that rely on smell.

**Actions**

- **Multiattack.** The bear makes two attacks: one with its bite and one with its claws.
    
- **Bite.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 8 (1d8 + 4) piercing damage.
    
- **Claws.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 11 (2d6 + 4) slashing damage.
    

---

### Dire Wolf

_Large beast, unaligned_

**Armor Class** 14 (natural armor)  
**Hit Points** 37 (5d10 + 10)  
**Speed** 50 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|17 (+3)|15 (+2)|15 (+2)|3 (-4)|12 (+1)|7 (-2)|

**Skills** Perception +3, Stealth +4  
**Senses** passive Perception 13  
**Challenge** 1 (200 XP)

**Keen Hearing and Smell.** The wolf has advantage on Wisdom (Perception) checks that rely on hearing or smell.

**Pack Tactics.** The wolf has advantage on attack rolls against a creature if at least one of the wolf's allies is within 5 feet of the creature and the ally isn't incapacitated.

**Actions**

- **Bite.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 10 (2d6 + 3) piercing damage. If the target is a creature, it must succeed on a DC 13 Strength saving throw or be knocked prone.
    

---

### Giant Spider

_Large beast, unaligned_

**Armor Class** 14 (natural armor)  
**Hit Points** 26 (4d10 + 4)  
**Speed** 30 ft., climb 30 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|14 (+2)|16 (+3)|12 (+1)|2 (-4)|11 (+0)|4 (-3)|

**Skills** Stealth +5  
**Senses** blindsight 10 ft., darkvision 60 ft., passive Perception 10  
**Challenge** 1 (200 XP)

**Spider Climb.** The spider can climb difficult surfaces, including upside down on ceilings, without needing to make an ability check.

**Web Sense.** While in contact with a web, the spider knows the exact location of any other creature in contact with the same web.

**Web Walker.** The spider ignores movement restrictions caused by webbing.

**Actions**

- **Bite.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one creature. _Hit:_ 7 (1d8 + 3) piercing damage, and the target must make a DC 11 Constitution saving throw, taking 9 (2d8) poison damage on a failed save, or half as much on a successful one. If the poison damage reduces the target to 0 hit points, the target is stable but poisoned for 1 hour, even after regaining hit points, and is paralyzed while poisoned in this way.
    
- **Web (Recharge 5-6).** _Ranged Weapon Attack:_ +5 to hit, range 30/60 ft., one creature. _Hit:_ The target is restrained by webbing. As an action, the restrained target can make a DC 12 Strength check, bursting the webbing on a success. The webbing can also be attacked and destroyed (AC 10; HP 5; vulnerability to fire damage; immunity to bludgeoning, poison, and psychic damage).
    

---

### Giant Toad

_Large beast, unaligned_

**Armor Class** 11  
**Hit Points** 39 (6d10 + 6)  
**Speed** 20 ft., swim 30 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|15 (+2)|13 (+1)|13 (+1)|2 (-4)|10 (+0)|3 (-4)|

**Senses** darkvision 30 ft., passive Perception 10  
**Challenge** 1 (200 XP)

**Amphibious.** The toad can breathe air and water.

**Standing Leap.** The toad's long jump is up to 20 feet and its high jump is up to 10 feet, with or without a running start.

**Actions**

- **Bite.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one target. _Hit:_ 7 (1d10 + 2) piercing damage, and the target is grappled (escape DC 11). Until this grapple ends, the target is restrained, and the toad can't bite another target.
    
- **Swallow.** The toad makes one bite attack against a Medium or smaller target it is grappling. If the attack hits, the target is swallowed, and the grapple ends. The swallowed target is blinded and restrained, has total cover against attacks and other effects outside the toad, and takes 10 (3d6) acid damage at the start of each of the toad's turns. The toad can have only one target swallowed at a time. If the toad dies, a swallowed creature is no longer restrained by it and can escape from the corpse using 5 feet of movement, exiting prone.
    

---

### Lion

_Large beast, unaligned_

**Armor Class** 12  
**Hit Points** 26 (4d10 + 4)  
**Speed** 50 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|17 (+3)|15 (+2)|13 (+1)|3 (-4)|12 (+1)|8 (-1)|

**Skills** Perception +3, Stealth +4  
**Senses** passive Perception 13  
**Challenge** 1 (200 XP)

**Keen Smell.** The lion has advantage on Wisdom (Perception) checks that rely on smell.

**Pack Tactics.** The lion has advantage on attack rolls against a creature if at least one of the lion's allies is within 5 feet of the creature and the ally isn't incapacitated.

**Pounce.** If the lion moves at least 20 feet straight toward a creature and then hits it with a claw attack on the same turn, that target must succeed on a DC 13 Strength saving throw or be knocked prone. If the target is prone, the lion can make one bite attack against it as a bonus action.

**Running Leap.** With a 10-foot running start, the lion can long jump up to 25 feet.

**Actions**

- **Bite.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 7 (1d8 + 3) piercing damage.
    
- **Claw.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 6 (1d6 + 3) slashing damage.
    

---

### Tiger

_Large beast, unaligned_

**Armor Class** 12  
**Hit Points** 37 (5d10 + 10)  
**Speed** 40 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|17 (+3)|15 (+2)|14 (+2)|3 (-4)|12 (+1)|8 (-1)|

**Skills** Perception +3, Stealth +4  
**Senses** darkvision 60 ft., passive Perception 13  
**Challenge** 1 (200 XP)

**Keen Smell.** The tiger has advantage on Wisdom (Perception) checks that rely on smell.

**Pounce.** If the tiger moves at least 20 feet straight toward a creature and then hits it with a claw attack on the same turn, that target must succeed on a DC 13 Strength saving throw or be knocked prone. If the target is prone, the tiger can make one bite attack against it as a bonus action.

**Actions**

- **Bite.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 8 (1d10 + 3) piercing damage.
    
- **Claw.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 7 (1d8 + 3) slashing damage.
    

---

### Giant Eagle

_Large beast, neutral good_

**Armor Class** 13  
**Hit Points** 26 (4d10 + 4)  
**Speed** 10 ft., fly 80 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|16 (+3)|17 (+3)|13 (+1)|8 (-1)|14 (+2)|10 (+0)|

**Skills** Perception +4  
**Senses** passive Perception 14  
**Languages** Giant Eagle understands Common and Auran but can't speak  
**Challenge** 1 (200 XP)

**Keen Sight.** The eagle has advantage on Wisdom (Perception) checks that rely on sight.

**Actions**

- **Multiattack.** The eagle makes two attacks: one with its beak and one with its talons.
    
- **Beak.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 6 (1d6 + 3) piercing damage.
    
- **Talons.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 10 (2d6 + 3) slashing damage.
    

⚠️ **Note:** Your player is level 3 and cannot use flying beasts yet. The Moon Druid table allows flying forms at level 8 (not level 4 as earlier stated — that's for non-Moon druids). Save Giant Eagle for later.

---

### Giant Hyena

_Large beast, unaligned_

**Armor Class** 12  
**Hit Points** 45 (6d10 + 12)  
**Speed** 50 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|16 (+3)|14 (+2)|14 (+2)|2 (-4)|12 (+1)|7 (-2)|

**Senses** passive Perception 11  
**Challenge** 1 (200 XP)

**Rampage.** When the hyena reduces a creature to 0 hit points with a melee attack on its turn, it can take a bonus action to move up to half its speed and make a bite attack.

**Actions**

- **Bite.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 10 (2d6 + 3) piercing damage.
    

---

## CR 1/2 Beasts

### Crocodile

_Large beast, unaligned_

**Armor Class** 12 (natural armor)  
**Hit Points** 19 (3d10 + 3)  
**Speed** 20 ft., swim 30 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|15 (+2)|10 (+0)|13 (+1)|2 (-4)|10 (+0)|5 (-3)|

**Skills** Stealth +2  
**Senses** passive Perception 10  
**Challenge** 1/2 (100 XP)

**Hold Breath.** The crocodile can hold its breath for 15 minutes.

**Actions**

- **Bite.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one creature. _Hit:_ 7 (1d10 + 2) piercing damage, and the target is grappled (escape DC 12). Until this grapple ends, the target is restrained, and the crocodile can't bite another target.
    

---

### Black Bear

_Medium beast, unaligned_

**Armor Class** 11 (natural armor)  
**Hit Points** 19 (3d8 + 6)  
**Speed** 40 ft., climb 30 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|15 (+2)|10 (+0)|14 (+2)|2 (-4)|12 (+1)|7 (-2)|

**Skills** Perception +3  
**Senses** passive Perception 13  
**Challenge** 1/2 (100 XP)

**Keen Smell.** The bear has advantage on Wisdom (Perception) checks that rely on smell.

**Actions**

- **Multiattack.** The bear makes two attacks: one with its bite and one with its claws.
    
- **Bite.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one target. _Hit:_ 5 (1d6 + 2) piercing damage.
    
- **Claws.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one target. _Hit:_ 7 (2d4 + 2) slashing damage.
    

---

### Ape

_Medium beast, unaligned_

**Armor Class** 12  
**Hit Points** 19 (3d8 + 6)  
**Speed** 30 ft., climb 30 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|16 (+3)|14 (+2)|14 (+2)|6 (-2)|12 (+1)|7 (-2)|

**Skills** Athletics +5, Perception +3  
**Senses** passive Perception 13  
**Challenge** 1/2 (100 XP)

**Actions**

- **Multiattack.** The ape makes two fist attacks.
    
- **Fist.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 6 (1d6 + 3) bludgeoning damage.
    
- **Rock.** _Ranged Weapon Attack:_ +5 to hit, range 25/50 ft., one target. _Hit:_ 6 (1d6 + 3) bludgeoning damage.
    

---

### Giant Goat

_Large beast, unaligned_

**Armor Class** 11 (natural armor)  
**Hit Points** 19 (3d10 + 3)  
**Speed** 40 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|17 (+3)|11 (+0)|13 (+1)|3 (-4)|12 (+1)|6 (-2)|

**Senses** passive Perception 11  
**Challenge** 1/2 (100 XP)

**Charge.** If the goat moves at least 20 feet straight toward a target and then hits it with a ram attack on the same turn, the target takes an extra 5 (2d4) bludgeoning damage. If the target is a creature, it must succeed on a DC 13 Strength saving throw or be knocked prone.

**Sure-Footed.** The goat has advantage on Strength and Dexterity saving throws made against effects that would knock it prone.

**Actions**

- **Ram.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 8 (2d4 + 3) bludgeoning damage.
    

---

### Warhorse

_Large beast, unaligned_

**Armor Class** 10  
**Hit Points** 19 (3d10 + 3)  
**Speed** 60 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|18 (+4)|12 (+1)|13 (+1)|2 (-4)|12 (+1)|7 (-2)|

**Senses** passive Perception 11  
**Challenge** 1/2 (100 XP)

**Trampling Charge.** If the horse moves at least 20 feet straight toward a creature and then hits it with a hooves attack on the same turn, that target must succeed on a DC 14 Strength saving throw or be knocked prone. If the target is prone, the horse can make another attack with its hooves against it as a bonus action.

**Actions**

- **Hooves.** _Melee Weapon Attack:_ +6 to hit, reach 5 ft., one target. _Hit:_ 11 (2d6 + 4) bludgeoning damage.
    

---

### Giant Wasp

_Medium beast, unaligned_

**Armor Class** 12  
**Hit Points** 13 (3d8)  
**Speed** 10 ft., fly 50 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|10 (+0)|14 (+2)|10 (+0)|1 (-5)|10 (+0)|3 (-4)|

**Senses** passive Perception 10  
**Challenge** 1/2 (100 XP)

**Actions**

- **Sting.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one creature. _Hit:_ 5 (1d6 + 2) piercing damage, and the target must make a DC 11 Constitution saving throw, taking 10 (3d6) poison damage on a failed save, or half as much on a successful one. If the poison damage reduces the target to 0 hit points, the target is stable but poisoned for 1 hour, even after regaining hit points, and is paralyzed while poisoned in this way.
    

⚠️ **Note:** Giant Wasp has a fly speed — not usable until level 8.

---

## CR 1/4 Beasts (Good Utility Options)

### Giant Wolf Spider

_Medium beast, unaligned_

**Armor Class** 13  
**Hit Points** 11 (2d8 + 2)  
**Speed** 40 ft., climb 40 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|12 (+1)|16 (+3)|13 (+1)|3 (-4)|12 (+1)|4 (-3)|

**Skills** Perception +3, Stealth +5  
**Senses** blindsight 10 ft., darkvision 60 ft., passive Perception 13  
**Challenge** 1/4 (50 XP)

**Spider Climb.** The spider can climb difficult surfaces, including upside down on ceilings, without needing to make an ability check.

**Web Walker.** The spider ignores movement restrictions caused by webbing.

**Actions**

- **Bite.** _Melee Weapon Attack:_ +3 to hit, reach 5 ft., one creature. _Hit:_ 4 (1d6 + 1) piercing damage, and the target must make a DC 11 Constitution saving throw, taking 7 (2d6) poison damage on a failed save, or half as much on a successful one. If the poison damage reduces the target to 0 hit points, the target is stable but poisoned for 1 hour, even after regaining hit points, and is paralyzed while poisoned in this way.
    

---

### Giant Frog

_Medium beast, unaligned_

**Armor Class** 11  
**Hit Points** 18 (4d8)  
**Speed** 30 ft., swim 30 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|12 (+1)|13 (+1)|11 (+0)|2 (-4)|10 (+0)|3 (-4)|

**Skills** Perception +2, Stealth +3  
**Senses** darkvision 30 ft., passive Perception 12  
**Challenge** 1/4 (50 XP)

**Amphibious.** The frog can breathe air and water.

**Standing Leap.** The frog's long jump is up to 20 feet and its high jump is up to 10 feet, with or without a running start.

**Actions**

- **Bite.** _Melee Weapon Attack:_ +3 to hit, reach 5 ft., one target. _Hit:_ 4 (1d6 + 1) piercing damage, and the target is grappled (escape DC 11). Until this grapple ends, the target is restrained, and the frog can't bite another target.
    
- **Swallow.** The frog makes one bite attack against a Small or smaller target it is grappling. If the attack hits, the target is swallowed, and the grapple ends. The swallowed target is blinded and restrained, has total cover against attacks and other effects outside the frog, and takes 5 (2d4) acid damage at the start of each of the frog's turns. The frog can have only one target swallowed at a time. If the frog dies, a swallowed creature is no longer restrained by it and can escape from the corpse using 5 feet of movement, exiting prone.
    

---

### Wolf

_Medium beast, unaligned_

**Armor Class** 13 (natural armor)  
**Hit Points** 11 (2d8 + 2)  
**Speed** 40 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|12 (+1)|15 (+2)|12 (+1)|3 (-4)|12 (+1)|6 (-2)|

**Skills** Perception +3, Stealth +4  
**Senses** passive Perception 13  
**Challenge** 1/4 (50 XP)

**Keen Hearing and Smell.** The wolf has advantage on Wisdom (Perception) checks that rely on hearing or smell.

**Pack Tactics.** The wolf has advantage on attack rolls against a creature if at least one of the wolf's allies is within 5 feet of the creature and the ally isn't incapacitated.

**Actions**

- **Bite.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one target. _Hit:_ 7 (2d4 + 2) piercing damage. If the target is a creature, it must succeed on a DC 11 Strength saving throw or be knocked prone.
    

---

### Boar

_Medium beast, unaligned_

**Armor Class** 11 (natural armor)  
**Hit Points** 11 (2d8 + 2)  
**Speed** 40 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|13 (+1)|11 (+0)|12 (+1)|2 (-4)|9 (-1)|5 (-3)|

**Senses** passive Perception 9  
**Challenge** 1/4 (50 XP)

**Charge.** If the boar moves at least 20 feet straight toward a target and then hits it with a tusk attack on the same turn, the target takes an extra 3 (1d6) slashing damage. If the target is a creature, it must succeed on a DC 11 Strength saving throw or be knocked prone.

**Relentless (Recharges after a Short or Long Rest).** If the boar takes 7 damage or less that would reduce it to 0 hit points, it is reduced to 1 hit point instead.

**Actions**

- **Tusks.** _Melee Weapon Attack:_ +3 to hit, reach 5 ft., one target. _Hit:_ 4 (1d6 + 1) slashing damage.
    

---

### Giant Lizard

_Large beast, unaligned_

**Armor Class** 12 (natural armor)  
**Hit Points** 19 (3d10 + 3)  
**Speed** 30 ft., climb 30 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|15 (+2)|12 (+1)|13 (+1)|2 (-4)|10 (+0)|5 (-3)|

**Senses** darkvision 30 ft., passive Perception 10  
**Challenge** 1/4 (50 XP)

**Actions**

- **Bite.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one target. _Hit:_ 6 (1d8 + 2) piercing damage.
    

---

### Giant Owl

_Large beast, neutral_

**Armor Class** 12  
**Hit Points** 19 (3d10 + 3)  
**Speed** 5 ft., fly 60 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|13 (+1)|15 (+2)|12 (+1)|8 (-1)|13 (+1)|10 (+0)|

**Skills** Perception +5, Stealth +4  
**Senses** darkvision 120 ft., passive Perception 15  
**Languages** Giant Owl understands Common, Sylvan, and Giant Owl but can't speak  
**Challenge** 1/4 (50 XP)

**Flyby.** The owl doesn't provoke opportunity attacks when it flies out of an enemy's reach.

**Keen Hearing and Sight.** The owl has advantage on Wisdom (Perception) checks that rely on hearing or sight.

**Actions**

- **Talons.** _Melee Weapon Attack:_ +3 to hit, reach 5 ft., one target. _Hit:_ 8 (2d6 + 1) slashing damage.
    

⚠️ **Note:** Flying speed — not usable until level 8.

---

### Riding Horse

_Large beast, unaligned_

**Armor Class** 10  
**Hit Points** 13 (2d10 + 2)  
**Speed** 60 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|16 (+3)|12 (+1)|13 (+1)|2 (-4)|11 (+0)|7 (-2)|

**Senses** passive Perception 10  
**Challenge** 1/4 (50 XP)

**Actions**

- **Hooves.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 8 (2d4 + 3) bludgeoning damage.
    

---

### Elk

_Large beast, unaligned_

**Armor Class** 10  
**Hit Points** 13 (2d10 + 2)  
**Speed** 50 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|16 (+3)|10 (+0)|12 (+1)|2 (-4)|10 (+0)|6 (-2)|

**Senses** passive Perception 10  
**Challenge** 1/4 (50 XP)

**Charge.** If the elk moves at least 20 feet straight toward a target and then hits it with a ram attack on the same turn, the target takes an extra 7 (2d6) bludgeoning damage. If the target is a creature, it must succeed on a DC 13 Strength saving throw or be knocked prone.

**Actions**

- **Ram.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 6 (1d6 + 3) bludgeoning damage.
    
- **Hooves.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one prone creature. _Hit:_ 8 (2d4 + 3) bludgeoning damage.
    

---

### Panther

_Medium beast, unaligned_

**Armor Class** 12  
**Hit Points** 13 (3d8)  
**Speed** 50 ft., climb 40 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|14 (+2)|15 (+2)|10 (+0)|3 (-4)|14 (+2)|7 (-2)|

**Skills** Perception +4, Stealth +6  
**Senses** passive Perception 14  
**Challenge** 1/4 (50 XP)

**Keen Smell.** The panther has advantage on Wisdom (Perception) checks that rely on smell.

**Pounce.** If the panther moves at least 20 feet straight toward a creature and then hits it with a claw attack on the same turn, that target must succeed on a DC 12 Strength saving throw or be knocked prone. If the target is prone, the panther can make one bite attack against it as a bonus action.

**Actions**

- **Bite.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one target. _Hit:_ 5 (1d6 + 2) piercing damage.
    
- **Claw.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one target. _Hit:_ 4 (1d4 + 2) slashing damage.
    

---

### Constrictor Snake

_Large beast, unaligned_

**Armor Class** 12  
**Hit Points** 13 (2d10 + 2)  
**Speed** 30 ft., swim 30 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|15 (+2)|14 (+2)|12 (+1)|1 (-5)|10 (+0)|3 (-4)|

**Senses** blindsight 10 ft., passive Perception 10  
**Challenge** 1/4 (50 XP)

**Actions**

- **Bite.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one creature. _Hit:_ 5 (1d6 + 2) piercing damage.
    
- **Constrict.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one creature. _Hit:_ 6 (1d8 + 2) bludgeoning damage, and the target is grappled (escape DC 12). Until this grapple ends, the creature is restrained, and the snake can't constrict another target.
    

---

## CR 1/8 Beasts

### Poisonous Snake

_Tiny beast, unaligned_

**Armor Class** 13  
**Hit Points** 2 (1d4)  
**Speed** 30 ft., swim 30 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|2 (-4)|16 (+3)|11 (+0)|1 (-5)|10 (+0)|3 (-4)|

**Senses** blindsight 10 ft., passive Perception 10  
**Challenge** 1/8 (25 XP)

**Actions**

- **Bite.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 1 piercing damage, and the target must make a DC 10 Constitution saving throw, taking 5 (2d4) poison damage on a failed save, or half as much on a successful one.
    

---

### Giant Rat

_Small beast, unaligned_

**Armor Class** 12  
**Hit Points** 7 (2d6)  
**Speed** 30 ft., climb 15 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|7 (-2)|15 (+2)|11 (+0)|2 (-4)|10 (+0)|4 (-3)|

**Senses** darkvision 60 ft., passive Perception 10  
**Challenge** 1/8 (25 XP)

**Keen Smell.** The rat has advantage on Wisdom (Perception) checks that rely on smell.

**Pack Tactics.** The rat has advantage on attack rolls against a creature if at least one of the rat's allies is within 5 feet of the creature and the ally isn't incapacitated.

**Actions**

- **Bite.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one target. _Hit:_ 4 (1d4 + 2) piercing damage.
    

---

### Mastiff

_Medium beast, unaligned_

**Armor Class** 12  
**Hit Points** 5 (1d8 + 1)  
**Speed** 40 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|13 (+1)|14 (+2)|12 (+1)|3 (-4)|12 (+1)|7 (-2)|

**Skills** Perception +3  
**Senses** passive Perception 13  
**Challenge** 1/8 (25 XP)

**Keen Hearing and Smell.** The mastiff has advantage on Wisdom (Perception) checks that rely on hearing or smell.

**Actions**

- **Bite.** _Melee Weapon Attack:_ +3 to hit, reach 5 ft., one target. _Hit:_ 4 (1d6 + 1) piercing damage. If the target is a creature, it must succeed on a DC 11 Strength saving throw or be knocked prone.
    

---

### Camel

_Large beast, unaligned_

**Armor Class** 9  
**Hit Points** 15 (2d10 + 4)  
**Speed** 50 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|16 (+3)|8 (-1)|14 (+2)|2 (-4)|8 (-1)|5 (-3)|

**Senses** passive Perception 9  
**Challenge** 1/8 (25 XP)

**Actions**

- **Bite.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 2 (1d4) bludgeoning damage.
    

---

### Flying Snake

_Tiny beast, unaligned_

**Armor Class** 14  
**Hit Points** 5 (2d4)  
**Speed** 30 ft., fly 60 ft., swim 30 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|4 (-3)|18 (+4)|11 (+0)|2 (-4)|12 (+1)|5 (-3)|

**Senses** blindsight 10 ft., passive Perception 11  
**Challenge** 1/8 (25 XP)

**Flyby.** The snake doesn't provoke opportunity attacks when it flies out of an enemy's reach.

**Actions**

- **Bite.** _Melee Weapon Attack:_ +6 to hit, reach 5 ft., one target. _Hit:_ 1 piercing damage plus 7 (3d4) poison damage.
    

⚠️ **Note:** Flying speed — not usable until level 8.

---

### Giant Crab

_Medium beast, unaligned_

**Armor Class** 15 (natural armor)  
**Hit Points** 13 (3d8)  
**Speed** 30 ft., swim 30 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|13 (+1)|15 (+2)|11 (+0)|1 (-5)|9 (-1)|3 (-4)|

**Skills** Stealth +4  
**Senses** blindsight 30 ft., passive Perception 9  
**Challenge** 1/8 (25 XP)

**Amphibious.** The crab can breathe air and water.

**Actions**

- **Claw.** _Melee Weapon Attack:_ +3 to hit, reach 5 ft., one target. _Hit:_ 4 (1d6 + 1) bludgeoning damage, and the target is grappled (escape DC 11). The crab has two claws, each of which can grapple only one target.
    

---

### Giant Weasel

_Medium beast, unaligned_

**Armor Class** 13  
**Hit Points** 9 (2d8)  
**Speed** 40 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|11 (+0)|16 (+3)|10 (+0)|4 (-3)|12 (+1)|5 (-3)|

**Skills** Perception +3, Stealth +5  
**Senses** darkvision 60 ft., passive Perception 13  
**Challenge** 1/8 (25 XP)

**Keen Hearing and Smell.** The weasel has advantage on Wisdom (Perception) checks that rely on hearing or smell.

**Actions**

- **Bite.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 5 (1d4 + 3) piercing damage.
    

---

### Blood Hawk

_Small beast, unaligned_

**Armor Class** 12  
**Hit Points** 7 (2d6)  
**Speed** 10 ft., fly 60 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|6 (-2)|14 (+2)|10 (+0)|3 (-4)|14 (+2)|5 (-3)|

**Skills** Perception +4  
**Senses** passive Perception 14  
**Challenge** 1/8 (25 XP)

**Keen Sight.** The hawk has advantage on Wisdom (Perception) checks that rely on sight.

**Pack Tactics.** The hawk has advantage on attack rolls against a creature if at least one of the hawk's allies is within 5 feet of the creature and the ally isn't incapacitated.

**Actions**

- **Beak.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one target. _Hit:_ 4 (1d4 + 2) piercing damage.
    

⚠️ **Note:** Flying speed — not usable until level 8.

---

## CR 0 Beasts (Scouting/Utility Options)

### Giant Fire Beetle

_Small beast, unaligned_

**Armor Class** 13 (natural armor)  
**Hit Points** 4 (1d6 + 1)  
**Speed** 30 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|8 (-1)|10 (+0)|12 (+1)|1 (-5)|10 (+0)|3 (-4)|

**Senses** blindsight 30 ft., passive Perception 10  
**Challenge** 0 (10 XP)

**Illumination.** The beetle sheds bright light in a 10-foot radius and dim light for an additional 10 feet.

**Actions**

- **Bite.** _Melee Weapon Attack:_ +1 to hit, reach 5 ft., one target. _Hit:_ 2 (1d6 - 1) piercing damage.
    

---

### Octopus

_Small beast, unaligned_

**Armor Class** 12  
**Hit Points** 3 (1d6)  
**Speed** 5 ft., swim 30 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|4 (-3)|15 (+2)|11 (+0)|3 (-4)|10 (+0)|4 (-3)|

**Skills** Perception +2, Stealth +4  
**Senses** darkvision 30 ft., passive Perception 12  
**Challenge** 0 (10 XP)

**Hold Breath.** While out of water, the octopus can hold its breath for 30 minutes.

**Underwater Camouflage.** The octopus has advantage on Dexterity (Stealth) checks made while underwater.

**Water Breathing.** The octopus can breathe only underwater.

**Actions**

- **Tentacles.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one target. _Hit:_ 1 bludgeoning damage, and the target is grappled (escape DC 10). Until this grapple ends, the octopus can't use its tentacles on another target.
    
- **Ink Cloud (Recharges after a Short or Long Rest).** A 5-foot-radius cloud of ink extends all around the octopus if it is underwater. The area is heavily obscured for 1 minute, although a significant current can disperse the ink. After releasing the ink, the octopus can use the Dash action as a bonus action.
    

---

### Baboon

_Small beast, unaligned_

**Armor Class** 12  
**Hit Points** 3 (1d6)  
**Speed** 30 ft., climb 30 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|8 (-1)|14 (+2)|11 (+0)|4 (-3)|12 (+1)|6 (-2)|

**Senses** passive Perception 11  
**Challenge** 0 (10 XP)

**Pack Tactics.** The baboon has advantage on attack rolls against a creature if at least one of the baboon's allies is within 5 feet of the creature and the ally isn't incapacitated.

**Actions**

- **Bite.** _Melee Weapon Attack:_ +1 to hit, reach 5 ft., one target. _Hit:_ 1 (1d4 - 1) piercing damage.
    

---

### Owl

_Tiny beast, unaligned_

**Armor Class** 11  
**Hit Points** 1 (1d4 - 1)  
**Speed** 5 ft., fly 60 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|3 (-4)|13 (+1)|8 (-1)|2 (-4)|12 (+1)|7 (-2)|

**Skills** Perception +3, Stealth +3  
**Senses** darkvision 120 ft., passive Perception 13  
**Challenge** 0 (10 XP)

**Flyby.** The owl doesn't provoke opportunity attacks when it flies out of an enemy's reach.

**Keen Hearing and Sight.** The owl has advantage on Wisdom (Perception) checks that rely on hearing or sight.

**Actions**

- **Talons.** _Melee Weapon Attack:_ +3 to hit, reach 5 ft., one target. _Hit:_ 1 slashing damage.
    

---

### Raven

_Tiny beast, unaligned_

**Armor Class** 12  
**Hit Points** 1 (1d4 - 1)  
**Speed** 10 ft., fly 50 ft.

|STR|DEX|CON|INT|WIS|CHA|
|---|---|---|---|---|---|
|2 (-4)|14 (+2)|8 (-1)|2 (-4)|12 (+1)|6 (-2)|

**Skills** Perception +3  
**Senses** passive Perception 13  
**Challenge** 0 (10 XP)

**Mimicry.** The raven can mimic simple sounds it has heard, such as a person whispering, a baby crying, or an animal chittering. A creature that hears the sounds can tell they are imitations with a successful DC 10 Wisdom (Insight) check.

**Actions**

- **Beak.** _Melee Weapon Attack:_ +4 to hit, reach 5 ft., one target. _Hit:_ 1 piercing damage.