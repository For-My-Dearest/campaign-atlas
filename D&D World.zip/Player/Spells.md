## Spellcasting

**Spell Save DC:** 13 (8 + 2 proficiency + 3 Wisdom)  
**Spell Attack Modifier:** +5  
**Prepared Spells:** 5 per day (3 Wisdom + 2 druid level)  
**Cantrips Known:** 2

**Spell Slots per long rest:**

| Level 1 | Level 2 |
| ------- | ------- |
| 4       | 2       |

---

## Cantrips

**Mending**
- _Casting Time:_ 1 minute
- _Range:_ Touch
- _Effect:_ You repair a single break or tear in an object you touch. It can mend a broken chain, a torn bag, or a cracked vial. The damage must be no larger than 1 foot in any dimension.

**Poison Spray**
- _Casting Time:_ 1 action
- _Range:_ 10 feet
- _Effect:_ You extend your hand and spray a cloud of poison. One creature you can see within range must make a Constitution saving throw (DC 13). On a failed save, it takes 1d12 poison damage. On a successful save, it takes no damage.
- _At Higher Levels:_ Damage increases by 1d12 at level 5 (2d12), level 11 (3d12), and level 17 (4d12).

---

## Prepared Spells (Level 1)

**Entangle** (concentration)
- _Casting Time:_ 1 action
- _Range:_ 90 feet
- _Area:_ 20-foot square
- _Duration:_ Up to 1 minute
- _Effect:_ Grasping weeds and vines sprout in the area. Each creature in the square must make a Strength saving throw (DC 13) or be restrained (speed 0, attacks against them have advantage, their attacks have disadvantage). A restrained creature can use its action to make a Strength check (DC 13) to break free.

**Cure Wounds**
- _Casting Time:_ 1 action
- _Range:_ Touch
- _Effect:_ A creature you touch regains 1d8 + 3 hit points.
- _At Higher Levels:_ Heals an additional 1d8 per spell slot level above 1st.

**Purify Food and Drink** (ritual)
- _Casting Time:_ 1 action (or 10 minutes as ritual)
- _Range:_ 10 feet
- _Effect:_ All nonmagical food and drink within a 5-foot-radius sphere is purified and rendered free of poison and disease.

**Thunderwave**
- _Casting Time:_ 1 action
- _Range:_ Self (15-foot cube)
- _Effect:_ A wave of thunderous force sweeps out from you. Each creature in a 15-foot cube originating from you must make a Constitution saving throw (DC 13). On a failed save, a creature takes 2d8 thunder damage and is pushed 10 feet away from you. On a successful save, it takes half damage and isn't pushed. Unsecured objects in the area are also pushed.
- _At Higher Levels:_ Damage increases by 1d8 per spell slot level above 1st.

---

## Prepared Spells (Level 2)

**Flame Blade** 
- _Casting Time:_ 1 bonus action
- _Range:_ Self
- _Duration:_ Up to 10 minutes
- _Effect:_ You summon a scimitar of fire in your free hand. It sheds bright light in 10 feet and dim light for another 10 feet. You are proficient with it. On each of your turns, you can use your action to make a melee spell attack (+5 to hit) with the blade. On a hit, it deals 3d6 fire damage. The blade vanishes after 10 minutes or if you lose concentration.

**Call Lightning** (concentration)
- _Casting Time:_ 1 action
- _Range:_ 120 feet
- _Duration:_ Up to 10 minutes
- _Effect:_ A storm cloud appears 100 feet above you. On each of your turns, you can use your action to call a lightning bolt down on a point you can see within 120 feet. Each creature within 5 feet of that point must make a Dexterity saving throw (DC 13). On a failed save, they take 3d10 lightning damage. On a success, half damage.
- _Requirement:_ You must be outdoors or in a space large enough to accommodate a 100-foot-tall cloud. If indoors, the spell fails unless the ceiling is very high.
