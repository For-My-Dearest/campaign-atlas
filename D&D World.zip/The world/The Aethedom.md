The great land before the seas.
Where all the stories unfold.

the world of beauty and aether

Kingdoms of The Aethedom:
[[The Solaris Empire]]
[[The Kingdom of Sylvanus]]
[[The Frostfell]]
[[The Drak-Garr Empire]]
[[The Etherium Archipelago]]
