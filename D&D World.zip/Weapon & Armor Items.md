
##  بخش اول: اسلحه‌ها (Weapons)

### سلاح‌های ساده (Simple Weapons)

#### سلاح‌های ساده - نبرد نزدیک (Simple Melee Weapons)

|نام|قیمت|آسیب|وزن|ویژگی‌ها|
|---|---|---|---|---|
|**Club** (چماق)|1 SP|1d4 Bludgeoning|2 lb.|Light|
|**Dagger** (خنجر)|2 GP|1d4 Piercing|1 lb.|Finesse, Light, Thrown (range 20/60)|
|**Greatclub** (چماق بزرگ)|2 SP|1d8 Bludgeoning|10 lb.|Two-Handed|
|**Handaxe** (تبر یک‌دست)|5 GP|1d6 Slashing|2 lb.|Light, Thrown (range 20/60)|
|**Javelin** (نیزه کوتاه)|5 SP|1d6 Piercing|2 lb.|Thrown (range 30/120)|
|**Light Hammer** (چکش سبک)|2 GP|1d4 Bludgeoning|2 lb.|Light, Thrown (range 20/60)|
|**Mace** (گرز)|5 GP|1d6 Bludgeoning|4 lb.|—|
|**Quarterstaff** (چوب دستی)|2 SP|1d6 Bludgeoning|4 lb.|Versatile (1d8)|
|**Sickle** (داس)|1 GP|1d4 Slashing|2 lb.|Light|
|**Spear** (نیزه)|1 GP|1d6 Piercing|3 lb.|Thrown (range 20/60), Versatile (1d8)|

#### سلاح‌های ساده - برد بلند (Simple Ranged Weapons)

|نام|قیمت|آسیب|وزن|ویژگی‌ها|
|---|---|---|---|---|
|**Crossbow, light** (کمان کوتاه دستی)|25 GP|1d8 Piercing|5 lb.|Ammunition (range 80/320), Loading, Two-Handed|
|**Dart** (دارت)|5 CP|1d4 Piercing|1/4 lb.|Finesse, Thrown (range 20/60)|
|**Shortbow** (کمان کوتاه)|25 GP|1d6 Piercing|2 lb.|Ammunition (range 80/320), Two-Handed|
|**Sling** (فلاخن)|1 SP|1d4 Bludgeoning|—|Ammunition (range 30/120)|

---

### سلاح‌های رزمی (Martial Weapons)

#### سلاح‌های رزمی - نبرد نزدیک (Martial Melee Weapons)

|نام|قیمت|آسیب|وزن|ویژگی‌ها|
|---|---|---|---|---|
|**Battleaxe** (تبر جنگی)|10 GP|1d8 Slashing|4 lb.|Versatile (1d10)|
|**Flail** (سنگین‌کش)|10 GP|1d8 Bludgeoning|2 lb.|—|
|**Glaive** (نیزه بلند)|20 GP|1d10 Slashing|6 lb.|Heavy, Reach, Two-Handed|
|**Greataxe** (تبر بزرگ)|30 GP|1d12 Slashing|7 lb.|Heavy, Two-Handed|
|**Greatsword** (شمشیر بزرگ)|50 GP|2d6 Slashing|6 lb.|Heavy, Two-Handed|
|**Halberd** (تبر نیزه‌ای)|20 GP|1d10 Slashing|6 lb.|Heavy, Reach, Two-Handed|
|**Lance** (نیزه سواره‌نظام)|10 GP|1d12 Piercing|6 lb.|Reach, Special|
|**Longsword** (شمشیر بلند)|15 GP|1d8 Slashing|3 lb.|Versatile (1d10)|
|**Maul** (پتک جنگی)|10 GP|2d6 Bludgeoning|10 lb.|Heavy, Two-Handed|
|**Morningstar** (گرز میخی)|15 GP|1d8 Piercing|4 lb.|—|
|**Pike** (نیزه بلند)|5 GP|1d10 Piercing|18 lb.|Heavy, Reach, Two-Handed|
|**Rapier** (شمشیر رطیل)|25 GP|1d8 Piercing|2 lb.|Finesse|
|**Scimitar** (شمشیر خمیده)|25 GP|1d6 Slashing|3 lb.|Finesse, Light|
|**Shortsword** (شمشیر کوتاه)|10 GP|1d6 Piercing|2 lb.|Finesse, Light|
|**Trident** (سه‌شاخ)|5 GP|1d6 Piercing|4 lb.|Thrown (range 20/60), Versatile (1d8)|
|**War Pick** (کلنگ جنگی)|5 GP|1d8 Piercing|2 lb.|—|
|**Warhammer** (چکش جنگی)|15 GP|1d8 Bludgeoning|2 lb.|Versatile (1d10)|
|**Whip** (شلاق)|2 GP|1d4 Slashing|3 lb.|Finesse, Reach|

#### سلاح‌های رزمی - برد بلند (Martial Ranged Weapons)

|نام|قیمت|آسیب|وزن|ویژگی‌ها|
|---|---|---|---|---|
|**Blowgun** (نیزه دمنده)|10 GP|1 Piercing|1 lb.|Ammunition (range 25/100), Loading|
|**Crossbow, hand** (کمان دستی)|75 GP|1d6 Piercing|3 lb.|Ammunition (range 30/120), Light, Loading|
|**Crossbow, heavy** (کمان سنگین)|50 GP|1d10 Piercing|18 lb.|Ammunition (range 100/400), Heavy, Loading, Two-Handed|
|**Longbow** (کمان بلند)|50 GP|1d8 Piercing|2 lb.|Ammunition (range 150/600), Heavy, Two-Handed|
|**Net** (تور)|1 GP|—|3 lb.|Special, Thrown (range 5/15)|

---

##  بخش دوم: زره‌ها (Armor)

### زره سبک (Light Armor)

|نام|قیمت|AC|Strength|Stealth|وزن|
|---|---|---|---|---|---|
|**Padded** (پددار)|5 GP|11 + Dex|—|Disadvantage|8 lb.|
|**Leather** (چرمی)|10 GP|11 + Dex|—|—|10 lb.|
|**Studded Leather** (چرمی میخ‌دار)|45 GP|12 + Dex|—|—|13 lb.|

### زره متوسط (Medium Armor)

|نام|قیمت|AC|Strength|Stealth|وزن|
|---|---|---|---|---|---|
|**Hide** (چرم خام)|10 GP|12 + Dex (max 2)|—|—|12 lb.|
|**Chain Shirt** (زره زنجیری کوتاه)|50 GP|13 + Dex (max 2)|—|—|20 lb.|
|**Scale Mail** (زره پولکی)|50 GP|14 + Dex (max 2)|—|Disadvantage|45 lb.|
|**Breastplate** (سینه‌بند)|400 GP|14 + Dex (max 2)|—|—|20 lb.|
|**Half Plate** (نیم‌زره)|750 GP|15 + Dex (max 2)|—|Disadvantage|40 lb.|

### زره سنگین (Heavy Armor)

|نام|قیمت|AC|Strength|Stealth|وزن|
|---|---|---|---|---|---|
|**Ring Mail** (زره حلقه‌ای)|30 GP|14|—|Disadvantage|40 lb.|
|**Chain Mail** (زره زنجیری)|75 GP|16|Str 13|Disadvantage|55 lb.|
|**Splint** (زره اسپلینت)|200 GP|17|Str 15|Disadvantage|60 lb.|
|**Plate** (زره صفحه‌ای)|1,500 GP|18|Str 15|Disadvantage|65 lb.|

### سپر (Shield)

|نام|قیمت|AC|وزن|
|---|---|---|---|
|**Shield** (سپر)|10 GP|+2|6 lb.|

---

## بخش سوم: اقلام جادویی (Magic Items)

### راهنمای کمیابی و سطح

|کمیابی (Rarity)|قیمت پیشنهادی|سطح بازیکن|
|---|---|---|
|**Common** (معمولی)|50-100 GP|هر سطح|
|**Uncommon** (نکمیاب)|100-500 GP|سطح 1 یا بالاتر|
|**Rare** (نایاب)|500-5,000 GP|سطح 5 یا بالاتر|
|**Very Rare** (بسیار نایاب)|5,000-50,000 GP|سطح 11 یا بالاتر|
|**Legendary** (افسانه‌ای)|50,000+ GP|سطح 17 یا بالاتر|
 **نکته:** قیمت‌ها تخمینی هستند. ارزش آیتم‌های مصرفی (مثل معجون یا طومار) معمولاً یک‌دهم آیتم دائمی با همان کمیابی است

---

### زره‌های جادویی (Magic Armor)

| نام                          | کمیابی    | نیاز به Attunement | کاربرد                                                                                                                      |
| ---------------------------- | --------- | ------------------ | --------------------------------------------------------------------------------------------------------------------------- |
| **Adamantine Armor**         | Uncommon  | —                  | ضربات بحرانی (Critical Hit) علیه تو تبدیل به ضربه معمولی می‌شوند                                                            |
| **Armor +1**                 | Rare      | —                  | +1 به AC                                                                                                                    |
| **Armor +2**                 | Very Rare | —                  | +2 به AC                                                                                                                    |
| **Armor +3**                 | Legendary | —                  | +3 به AC                                                                                                                    |
| **Armor of Resistance**      | Rare      | ★                  | مقاومت در برابر یک نوع آسیب (اسید، سرما، آتش، نیرو، صاعقه، نکروتیک، زهر، روانی، تابشی، تندر)                                |
| **Armor of Invulnerability** | Legendary | ★                  | مقاومت در برابر آسیب غیرجادویی؛ یک بار در روز می‌توانی برای ۱۰ دقیقه ایمن شوی[](https://critgames.com/dnd5e/magical-items/) |
| **Dwarven Plate**            | Very Rare | —                  | +2 به AC؛ اگر اثری تو را جابجا کند، می‌توانی تا ۱۰ فوت کم کنی                                                               |
| **Shield +1**                | Uncommon  | —                  | +1 به AC                                                                                                                    |
| **Shield +2**                | Rare      | —                  | +2 به AC                                                                                                                    |
| **Shield +3**                | Very Rare | —                  | +3 به AC                                                                                                                    |
| **Animated Shield**          | Very Rare | ★                  | سپر به فرمان تو پرواز می‌کند و دست‌هایت را آزاد می‌گذارد                                                                    |
| **Arrow-Catching Shield**    | Rare      | ★                  | +2 به AC در برابر حملات دوربرد؛ می‌توانی هدف حملات دوربرد بشوی                                                              |

---

### سلاح‌های جادویی (Magic Weapons)

| نام                  | کمیابی    | نیاز به Attunement | کاربرد                                                                                      |
| -------------------- | --------- | ------------------ | ------------------------------------------------------------------------------------------- |
| **Weapon +1**        | Uncommon  | —                  | +1 به Attack Rolls و Damage Rolls                                                           |
| **Weapon +2**        | Rare      | —                  | +2 به Attack Rolls و Damage Rolls                                                           |
| **Weapon +3**        | Very Rare | —                  | +3 به Attack Rolls و Damage Rolls                                                           |
| **Ammunition +1**    | Uncommon  | —                  | مهمات جادویی با +1 به Attack و Damage                                                       |
| **Ammunition +2**    | Rare      | —                  | مهمات جادویی با +2 به Attack و Damage                                                       |
| **Ammunition +3**    | Very Rare | —                  | مهمات جادویی با +3 به Attack و Damage                                                       |
| **Arrow of Slaying** | Very Rare | —                  | ضربه به نوع خاصی از موجودات +6d10 آسیب می‌زند[](https://critgames.com/dnd5e/magical-items/) |
| **Vorpal Sword**     | Legendary | ★                  | با 20 طبیعی، سر حریف را می‌بری                                                              |
| **Flametongue**      | Rare      | ★                  | فرمان بده تا شعله‌ور شود و +2d6 آسیب آتش بزند                                               |
| **Frost Brand**      | Very Rare | ★                  | مقاومت در برابر آتش، +1d6 آسیب سرما                                                         |
| **Giant Slayer**     | Rare      | ★                  | +1 به Attack و Damage؛ به غول‌ها +2d6 آسیب اضافه می‌زند                                     |

---


### معجون‌ها (Potions)

| نام                                     | کمیابی    | کاربرد ها                                              |
| --------------------------------------- | --------- | ------------------------------------------------------ |
| **Potion of Healing** (2d4+2)           | Common    | 2d4 + 2 HP بازیابی                                     |
| **Potion of Greater Healing** (4d4+4)   | Uncommon  | 4d4 + 4 HP بازیابی                                     |
| **Potion of Superior Healing** (8d4+8)  | Rare      | 8d4 + 8 HP بازیابی                                     |
| **Potion of Supreme Healing** (10d4+20) | Very Rare | 10d4 + 20 HP بازیابی                                   |
| **Potion of Invisibility**              | Very Rare | به مدت ۱ ساعت نامرئی می‌شوی                            |
| **Potion of Flying**                    | Very Rare | به مدت ۱ ساعت سرعت پرواز ۶۰ فوت می‌گیری                |
| **Potion of Giant Strength**            | Rare+     | Strength برای مدت کوتاهی به مقدار زیادی افزایش می‌یابد |

---